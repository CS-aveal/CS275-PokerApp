import UIKit
import Foundation

enum _suit: CaseIterable{
    case spade,club,diamond,heart
}
enum _rank: Comparable{
    case highCard,pair,twoPair,trips,straight,flush,fullHouse,quads,straightFlush
}

//card struct
struct Card : Comparable{
    var number: Int
    var suit:_suit
    
    init(num:Int, cardSuit:_suit) {
        number = num
        suit = cardSuit
    }
    func printCard() -> String{
        var numberPart: String
        var suitPart: String
        
        switch suit{
        case .spade:
            suitPart = " of spades"
        case .heart:
            suitPart = " of hearts"
        case .diamond:
            suitPart = " of diamonds"
        case .club:
            suitPart = " of clubs"
        }
        switch number{
        case 11:
            numberPart = "Jack"
        case 12:
            numberPart = "Queen"
        case 13:
            numberPart = "King"
        case 14:
            numberPart = "Ace"
        default:
            numberPart = String(number)
        }
        return numberPart + suitPart
    }
    
    //overloaded operators
    static func ==(lhs:Card, rhs:Card) -> Bool {
        return lhs.number == rhs.number
    }
    static func >(lhs:Card, rhs:Card) -> Bool {
        return lhs.number > rhs.number
    }
    static func <(lhs:Card, rhs:Card) -> Bool {
        return lhs.number < rhs.number
    }
    static func >=(lhs:Card, rhs:Card) -> Bool {
        return lhs.number >= rhs.number
    }
    static func <=(lhs:Card, rhs:Card) -> Bool {
        return lhs.number <= rhs.number
    }
    
}

//Deck struct
struct Deck{
    var cardDeck: [Card] = []
    init() {
        cardDeck.removeAll()
        for val in 2...14{
            for eachSuit in _suit.allCases{
                cardDeck.append(Card(num:val, cardSuit: eachSuit))
            }
        }
    }
    func printDeck(){
        for eachCard in cardDeck{
            print(eachCard.printCard())
        }
    }
    mutating func shuffleDeck(){
        cardDeck.shuffle()
    }
    func getTop() -> Card{
        return cardDeck[0]
    }
    mutating func popTop() -> Card{
        let topCard = cardDeck[0]
        cardDeck.removeFirst()
        return topCard
    }
}

//PlayerHand struct
struct PlayerHand{
    var hand: [Card] = []
    var rank: _rank = _rank.highCard
    //Individual rank variables:
    //high card:
    var fiveHighest: [Int] = []
    //pair:
    var firstPairRank = 0
    var threeOthers: [Int] = []
    //two pair:
    var secondPairRank = 0
    var twoPairKicker = 0
    //trips:
    var tripsRank = 0
    var twoKickers:[Int] = []
    //straight:
    var straightHigh = 0
    //flush:
    var flushVals:[Int] = []
    //full house:
    //set of 3 = tripsRank
    var twoSet = 0
    //quads:
    var quadsRank = 0
    var quadsKicker = 0
    //straight flush:
    var straightFlushHigh = 0


    
    mutating func addCard(cardToAdd: Card){
        hand.append(cardToAdd)
    }
    
    
    mutating func getRank(){
        
        hand.sort() //sort hand in ascending order
        //set rank = highCard with highest card
        rank = _rank.highCard
        for card in hand.reversed(){
            if fiveHighest.count < 5{
                fiveHighest.append(card.number)
            }
        }
        
        //get card counts, store in dictionary
        var countDict: [Int:Int] = [:] //initialize dictionary
        for card in hand{
            countDict[card.number] = (countDict[card.number] ?? 0) + 1 //store counts in dictionary: [CardNumber:count]
        }
        //check pair
        for (cardNum, count) in countDict{
            if count == 2{
                if cardNum > firstPairRank{
                    rank = _rank.pair
                    firstPairRank = cardNum
                }
            }
        }
        if rank == _rank.pair {
            for card in hand.reversed(){
                if card.number != firstPairRank && threeOthers.count < 3{
                    threeOthers.append(card.number)
                }
            }
        }
        //check two pair
        for (cardNum, count) in countDict{
            if count == 2{
                if cardNum != firstPairRank && cardNum > secondPairRank{
                    rank = _rank.twoPair
                    secondPairRank = cardNum
                }
            }
        }
        if rank == _rank.twoPair {
            for card in hand.reversed(){
                if card.number != firstPairRank && card.number != secondPairRank && twoPairKicker == 0{
                    twoPairKicker = card.number
                }
            }
        }
        
        //check trips
        for (cardNum, count) in countDict{
            if count == 3{
                if cardNum > tripsRank{
                    rank = _rank.trips
                    tripsRank = cardNum
                }
            }
        }
        if rank == _rank.trips{
            for card in hand.reversed(){
                if card.number != tripsRank && twoKickers.count < 2{
                    twoKickers.append(card.number)
                }
            }
        }
        
        //check straight
        //make unique hand
        var handUnique: [Card] = []
        for card in hand{
            if !handUnique.contains(card){
                handUnique.append(card)
            }
        }
        //check straight (and straight flush)
        var straightFlush = false
        if handUnique.count - 5 >= 0{
            for i in 0...(handUnique.count-5){
                if ((handUnique[i+1].number == handUnique[i].number + 1) && (handUnique[i+2].number == handUnique[i].number + 2) && (handUnique[i+3].number == handUnique[i].number + 3) && (handUnique[i+4].number == handUnique[i].number + 4)){
                    rank = _rank.straight
                    straightHigh = handUnique[i+4].number
                    //check for straight flush
                    if handUnique[i].suit == handUnique[i+1].suit && handUnique[i].suit == handUnique[i+2].suit && handUnique[i].suit == handUnique[i+3].suit && handUnique[i].suit == handUnique[i+4].suit{
                        straightFlush = true
                        straightFlushHigh = handUnique[i+4].number
                    }
                    
                }
            }
        }
        //check flush
        var spades = 0, clubs = 0, diamonds = 0, hearts = 0
        var flushSuit: _suit = _suit.spade
        var flushBool = false
        for card in hand{
            switch card.suit{
            case _suit.spade:
                spades += 1
                if spades >= 5{
                    flushBool = true
                    flushSuit = _suit.spade
                }
            case _suit.diamond:
                diamonds += 1
                if diamonds >= 5{
                    flushBool = true
                    flushSuit = _suit.diamond
                }
            case _suit.club:
                clubs += 1
                if clubs >= 5{
                    flushBool = true
                    flushSuit = _suit.club
                }
            case _suit.heart:
                hearts += 1
                if hearts >= 5{
                    flushBool = true
                    flushSuit = _suit.heart
                }
            }
        }
        if flushBool{
            rank = _rank.flush
            for card in hand.reversed(){
                if card.suit == flushSuit && flushVals.count < 5{
                    flushVals.append(card.number)
                }
            }
        }
        //check full house
        if tripsRank > 0{
            for (cardNum, count) in countDict{
                if count >= 2{
                    if cardNum > twoSet && cardNum != tripsRank{
                        rank = _rank.fullHouse
                        twoSet = cardNum
                    }
                }
            }
        }
        //check quads
        for (cardNum, count) in countDict{
            if count == 4{
                rank = _rank.quads
                quadsRank = cardNum
                for card in hand.reversed(){
                    if card.number != quadsRank && quadsKicker == 0{
                        quadsKicker = card.number
                    }
                }
            }
        }
        //check straight flush
        if straightFlush{
            rank = _rank.straightFlush
        }
    }
    
    func printRank(){
        print("Rank: ", terminator: "")
        switch rank{
        case _rank.highCard:
            print("High Card. 5 cards: \(fiveHighest)")
        case _rank.pair:
            print("Pair of \(firstPairRank). Kickers: \(threeOthers)")
        case _rank.twoPair:
            print("Two pair of \(firstPairRank) and \(secondPairRank). Kicker: \(twoPairKicker)")
        case _rank.trips:
            print("Three of a kind: \(tripsRank). Kickers: \(twoKickers)")
        case _rank.straight:
            print("Straight, \(straightHigh) high")
        case _rank.flush:
            print("Flush. Five highest: \(flushVals)")
        case _rank.fullHouse:
            print("Full house. \(tripsRank) full of \(twoSet)")
        case _rank.quads:
            print("Four of a kind: \(quadsRank). Kicker: \(quadsKicker)")
        case _rank.straightFlush:
            print("Straight flush. \(straightFlushHigh) high.")
        }
    }
    //overloaded operators
    static func == (lhs:PlayerHand, rhs:PlayerHand) -> Bool{
        if lhs.rank != rhs.rank{
            return false
        } else {
            switch lhs.rank {
            case .highCard:
                return lhs.fiveHighest == rhs.fiveHighest
            case .pair:
                return (lhs.firstPairRank == rhs.firstPairRank && lhs.threeOthers == rhs.threeOthers)
            case .twoPair:
                return (lhs.firstPairRank == rhs.firstPairRank && lhs.secondPairRank == rhs.secondPairRank && lhs.twoPairKicker == rhs.twoPairKicker)
            case .trips:
                return (lhs.tripsRank == rhs.tripsRank && lhs.twoKickers == rhs.twoKickers)
            case .straight:
                return lhs.straightHigh == rhs.straightHigh
            case .flush:
                return lhs.flushVals == rhs.flushVals
            case .fullHouse:
                return (lhs.tripsRank == rhs.tripsRank && lhs.twoSet == rhs.twoSet)
            case .quads:
                return (lhs.quadsRank == rhs.quadsRank && lhs.quadsKicker == rhs.quadsKicker)
            case .straightFlush:
                return lhs.straightFlushHigh == rhs.straightFlushHigh
            }
        }
    }
    static func > (lhs:PlayerHand, rhs:PlayerHand) -> Bool {
        if lhs.rank > rhs.rank{
            return true
        } else if lhs.rank < rhs.rank{
            return false
        } else{ //ranks are equal
            switch lhs.rank{
            case .highCard:
                for (val1,val2) in zip(lhs.fiveHighest, rhs.fiveHighest){
                    if val1 > val2{
                        return true
                    } else if val1 < val2 {
                        return false
                    }
                }
                return false //equal
            case .pair:
                if lhs.firstPairRank > rhs.firstPairRank {
                    return true
                } else if lhs.firstPairRank < rhs.firstPairRank {
                    return false
                } else { //pair equal
                    for (val1,val2) in zip(lhs.threeOthers, rhs.threeOthers){
                        if val1 > val2{
                            return true
                        } else if val1 < val2 {
                            return false
                        }
                    }
                    return false
                }
            case .twoPair:
                if lhs.firstPairRank > rhs.firstPairRank{
                    return true
                } else if lhs.firstPairRank < rhs.firstPairRank {
                    return false
                } else if lhs.secondPairRank > rhs.secondPairRank{
                    return true
                } else if lhs.secondPairRank < rhs.secondPairRank{
                    return false
                } else{ //both pairs equal, check kicker
                    return lhs.twoPairKicker > rhs.twoPairKicker
                }
            case .trips:
                if lhs.tripsRank > rhs.tripsRank{
                    return true
                } else if lhs.tripsRank < rhs.tripsRank{
                    return false
                } else {//trips equal, check kickers
                    for (val1,val2) in zip(lhs.twoKickers, rhs.twoKickers){
                        if val1 > val2 {
                            return true
                        } else if val1 < val2 {
                            return false
                        }
                    }
                    return false
                }
            case .straight:
                return lhs.straightHigh > rhs.straightHigh
            case .flush:
                for (val1,val2) in zip(lhs.flushVals, rhs.flushVals){
                    if val1 > val2 {
                        return true
                    } else if val1 < val2 {
                        return false
                    }
                }
                return false
            case .fullHouse:
                if lhs.tripsRank > rhs.tripsRank {
                    return true
                } else if lhs.tripsRank < rhs.tripsRank{
                    return false
                } else if lhs.twoSet > rhs.twoSet{
                    return true
                } else if lhs.twoSet < rhs.twoSet{
                    return false
                } else{ //same full house
                    return false
                }
            case .quads:
                if lhs.quadsRank > rhs.quadsRank{
                    return true
                } else if lhs.quadsRank < rhs.quadsRank{
                    return false
                } else{//same quads, check kicker
                    return lhs.quadsKicker > rhs.quadsKicker
                }
            case .straightFlush:
                return lhs.straightFlushHigh > rhs.straightFlushHigh
            }
        }
    }
    static func < (lhs:PlayerHand, rhs:PlayerHand) -> Bool{
        if (!(lhs == rhs) && !(lhs>rhs)){
            return true
        } else{
            return false
        }
    }
}

//CODE BELOW THIS POINT IS ALL STILL IN PROGRESS

//enums
enum _state: CaseIterable{
    case preflop, flop, turn, river, over, reset
}
enum _action{
    case dealCards, dealFlop, dealTurn, dealRiver, doBets
}
enum _options{
    case allOptions, noCheck, allInNoOptions
}
enum _choice {
    case check,fold,call,raise
}
//Player struct
class Player{
    var name:String
    var stack:Int = 0
    var privateHand:[Card] = []
    var hand:PlayerHand
    var inRound = true
    var currentBet: Int = 0
    var roundBet: Int = 0
    var turn = false
    var dealer = false
    var options: _options
    var choice: _choice
    
    func bet(){
        
    }
    func call(){
        
    }
    func check(){
        
    }
    func raise(){
        
    }
    func fold(){
        
    }
    func dealPrivateHand(d: inout Deck){
        privateHand.append(d.popTop())
        privateHand.append(d.popTop())
    }
    func payPot(_ r: inout Round){
        stack += r.potSize
        r.potSize = 0
    }
    
}

//Round struct: stores information that needs to be updated constantly(with every player action or at the end of each round)
struct Round{
    var state:_state
    var playersIn:[Player] = []
    var commonCards:[Card] = []
    var potSize = 0
    var betVals:[Int] = []
    var highestBet:Int = 0
    var dealerPlayed = false
    var deck: Deck
    
    init(roundState:_state,playersStillIn:[Player],centerCards:[Card],totalPot:Int,bets:[Int],highBet:Int,dealerPlay:Bool,roundDeck:Deck){
        state = roundState
        playersIn = playersStillIn
        commonCards = centerCards
        potSize = totalPot
        betVals = bets
        highestBet = highBet
        dealerPlayed = dealerPlay
        deck = roundDeck
    }
    mutating func resetRound(g: inout Game){
        playersIn = g.allPlayers
        potSize = 0
        betVals.removeAll()
        dealerPlayed = false
        commonCards.removeAll()
        state = _state.preflop
        deck = Deck()
        deck.shuffleDeck()
    }
}
//Game struct: stores information that only needs to be updated occasionally, like the array of players
struct Game{
    var allPlayers:[Player] = []
    init(players:[Player]){
        allPlayers = players
    }
}

func readData(){
    //read in data from file/server
}

//EXECUTE ACTION
func doAction(r: inout Round, a: _action,g: inout Game){
    switch a{
    case .dealCards:
        //First Reset round
        //set dealer
        
        //Then deal cards
        for player in r.playersIn{
            player.dealPrivateHand(d: &r.deck)
        }
    case .dealFlop:
        for _ in 0...2{
            r.commonCards.append(r.deck.popTop())
        }
    case .dealTurn:
        r.commonCards.append(r.deck.popTop())
    case .dealRiver:
        r.commonCards.append(r.deck.popTop())
    case .doBets:
        enum choice {
            case check, fold, raise, call
        }
        var raiseVal: Int
        var currentPlayer:Player
        var PlayerIndex: Int
        for (i, player) in r.playersIn.enumerated(){
            if player.turn{
                currentPlayer = player
                PlayerIndex = i
            }
        }
        switch currentPlayer.options{ //needs to check that player == local player
        case .allOptions:
            //all buttons available
            //wait for input. Set choice and raiseval if applicable
            
        case .noCheck:
            //allow all button except check button
            //wait for input. Set choice and raiseval if applicable
        case .allInNoOptions:
            //player is all in. Cannot make further input, all buttons unavailable
            //don't wait for input. Proceed to process and write to server
        }
        if currentPlayer.dealer{
            r.dealerPlayed = true
        }
        switch currentPlayer.choice{
            
        case .check:
            <#code#>
        case .fold:
            r.playersIn.remove(at: PlayerIndex)
        case .call:
            currentPlayer.stack - (r.highestBet - currentPlayer.currentBet)
            currentPlayer.currentBet = r.highestBet

        case .raise:
            <#code#>
        }
    }
}

//DETERMINE NEXT ACTION
func determineAction(r: inout Round, g: inout Game){
    //helper function
    func getNextIndex(_ r: Round, _ i:Int) -> Int{
        if i == r.playersIn.count - 1{
            return 0
        } else{
            return i + 1
        }
    }
    //declare player references to use throughout function
    var currentPlayer: Player
    var nextPlayer: Player
    var winner: Player
    for (index, player) in r.playersIn.enumerated() {
        if player.turn == true{
            currentPlayer = player
            currentPlayer.turn = false
            nextPlayer = r.playersIn[getNextIndex(r,index)]
            
        }
    }
    //Determine action
    if r.playersIn.count == 1{
       //round over via fold
        winner = r.playersIn[0]
        winner.payPot(&r)
        r.resetRound(g: &g)
    } else if r.dealerPlayed && r.playersIn.allSatisfy({$0.roundBet == r.highestBet}){
        //end round
        for (index, player) in r.playersIn.enumerated(){
            if player.dealer{
                r.playersIn[getNextIndex(r, index)].turn = true
            }
        }
        //set state enum to next value
        switch r.state{
        case .preflop:
            r.state = .flop
        case .flop:
            r.state = .turn
        case .turn:
            r.state = .river
        case .river:
            r.state = .over
        case .over:
            <#code#>
        case .reset:
            <#code#>
        }
        //reset bets
        for player in r.playersIn{
            player.roundBet = 0
        }
        r.betVals.removeAll()
    }else{
        //continue round
        //set next player
        nextPlayer.turn = true
        //set next player's options
        if r.highestBet == 0{
            nextPlayer.options = _options.allOptions
        } else {
            nextPlayer.options = _options.noCheck
        }
    }
}

func writeData(r: inout Round){
    
}


//var firstCard = Card(num:13,cardSuit: _suit.diamond)
//var secondCard = Card(num:13,cardSuit: _suit.club)
//print(firstCard.printCard())
//print(firstCard == secondCard)

//var firstDeck = Deck()
//firstDeck.shuffleDeck()
//firstDeck.printDeck()
//print(firstDeck.cardDeck.count)
//print()
//print(firstDeck.popTop().printCard())
//println()
//firstDeck.printDeck()
//print(firstDeck.cardDeck.count)

var firstHand = PlayerHand()
firstHand.addCard(cardToAdd: Card(num:3,cardSuit: _suit.diamond))
firstHand.addCard(cardToAdd: Card(num:2,cardSuit: _suit.club))
firstHand.addCard(cardToAdd: Card(num:2,cardSuit: _suit.heart))
firstHand.addCard(cardToAdd: Card(num:3,cardSuit: _suit.diamond))
firstHand.addCard(cardToAdd: Card(num:3,cardSuit: _suit.club))
firstHand.addCard(cardToAdd: Card(num:6,cardSuit: _suit.diamond))
firstHand.addCard(cardToAdd: Card(num:2,cardSuit: _suit.diamond))
firstHand.getRank()
firstHand.printRank()
print()
var secondHand = PlayerHand()
secondHand.addCard(cardToAdd: Card(num:4,cardSuit: _suit.diamond))
secondHand.addCard(cardToAdd: Card(num:4,cardSuit: _suit.diamond))
secondHand.addCard(cardToAdd: Card(num:4,cardSuit: _suit.diamond))
secondHand.addCard(cardToAdd: Card(num:5,cardSuit: _suit.diamond))
secondHand.addCard(cardToAdd: Card(num:3,cardSuit: _suit.diamond))
secondHand.addCard(cardToAdd: Card(num:2,cardSuit: _suit.diamond))
secondHand.addCard(cardToAdd: Card(num:3,cardSuit: _suit.diamond))
secondHand.getRank()
secondHand.printRank()
print()
print(firstHand==secondHand)

